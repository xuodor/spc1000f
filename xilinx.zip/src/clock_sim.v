`timescale 1ns / 1ps

module clocks (
    input  wire clk_in,   // 50 MHz input clock
    output reg  clk_25,   // 25 MHz generated clock
    output reg  clk_12,   // 12 MHz generated clock
    output reg  clk_4,    //  4 MHz generated clock
    input  wire RESET,     // Active-high RESET input
    output reg  LOCKED     // PLL Lock indicator
);

   initial begin
      clk_25 = 1'b0;
      clk_12 = 1'b0;
      
      clk_4 = 1'b0;
      LOCKED = 1'b0;
      acc = 5'd0;
   end

   reg [5:0] acc;
   
   always @(posedge clk_in or posedge RESET) begin
      if (RESET) begin
	 acc <= 0;
         clk_25 <= 1'b0;
         clk_12 = 1'b0;
	 clk_4 <= 1'b0;
         LOCKED <= 1'b0;
      end else begin
	 clk_25 <= ~clk_25;
	 // 25 divided by 4 is 6.25, a standard counter results in
	 // slight duty-cycle jitter. This logic tracks the exact
	 // fractional phase using a modulo-25 accumulator.
	 if (acc >= 25) begin
	    acc <= acc + 8 - 25;
	    clk_4 <= ~clk_4;
	 end else begin
	    acc <= acc + 8;
	 end	   
	 LOCKED <= 1'b1; // Simulate immediate PLL lock
      end
   end
   assign clk32 = 1'b0;  // 32 MHz not in action

endmodule
